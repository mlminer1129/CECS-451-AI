#-------------------------------------------------------------------
#	Converts a standard gameboard to a graph file
#				 
#	(c) 2020 Arjang Fahim
#
#	Date: 4/10/2020
#	email: fahim.arjang@csulb.edu
#   version: 1.0.0
#------------------------------------------------------------------

import pandas as pd
import numpy as np


class GameBoard(object):
	
	def __init__(self, maze_file):

		# load your data here
		pass

    # returns goal node position
	def GoalNode(self):
		return self.goal

	# returns starting node position	
	def StartNode(self):
		return self.start

	def MazeMatrix_Build(self):
		pass
		

	def SaveMatrix(self, path):
		pass

	def PlotSolution(self, solution, path):
		# Don't worry about it for now, we may use it foe the next assignment
		pass




#------------------------[End of class Gameboard]----------------------------------------	


		